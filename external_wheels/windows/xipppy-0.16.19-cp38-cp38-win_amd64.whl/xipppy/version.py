# PATCH_LEVEL is zero for local developer builds and the Jenkins build number
# for Jenkins builds, including the production build.  This is filled in by
# cmake.

xipppy_version = [0, 16, 19]
xipppy_str = "{}.{}.{}".format(*xipppy_version)
