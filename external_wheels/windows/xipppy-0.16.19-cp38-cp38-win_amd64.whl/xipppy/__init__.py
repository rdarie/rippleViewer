"""
XIPP communications with Trellis and Grapevine.

Before using any other library features, call open() and call close() when
done. There can only be one connection open at a time; it may sometimes be
useful to close() and re-open() the network connection.

Most functions will raise a XippPyException on error. The underlying library
does not offer useful information on the cause of an error in most cases,
so these (unfortunately) tend to lack additional information.

Property-setting functions (like stim_enable_set(), signal_set() or
filter_set()) are asynchronous- the change will not take effect immediately
since it must be sent across the XIPP connection. If it is important that
a property change be applied before the program continues, you should poll
for the desired value:

    stim_enable_set(1)
    for _ in range(1,100):
        time.sleep(.01)
        if stim_enable() == 1:
            break
    else:
        raise Exception("Timed out waiting for stim enable to take effect")
"""
import array
import ctypes
import itertools
import logging

import xipppy_capi as _c
from . import exception

from .version import (
    xipppy_str
)
from .fast_settle import (
    fast_settle,
    fast_settle_get_choices,
    fast_settle_get_duration,
)
from .filter import (
    SosFilterDesc,
    SosStage,
    filter_get_desc,
    filter_list_names,
    filter_list_selection,
    filter_set,
    filter_set_custom
)
from .stim import (
    StimSegment,
    StimSeq,
    stim_enable,
    stim_enable_set,
    stim_get_res,
    stim_set_res
)
from .transceiver import (
    TransceiverCmdHeader,
    TransceiverRegisterAddrs,
    TransceiverStatus,
    TransceiverCommand,
    TRANSCEIVER_STATUS_COUNTER_MAX,
    ImplantRegisterAddrs,
    POWER_STATE_R3,
    DEFAULT_SERVO_DAC_LEVEL,
    transceiver_status,
    transceiver_command,
    transceiver_enable,
    transceiver_connected,
    transceiver_power_servo_enable,
    transceiver_get_power_state,
    transceiver_get_implant_serial,
    transceiver_get_implant_voltage,
    transceiver_get_ir_led_level,
    transceiver_get_ir_received_light,
    transceiver_set_implant_servo_dac
)
from .mira import (
    MiraImplantCmdMode
)
from .hardware import (
    hw_ground,
    hw_reference
)
from .sensors import (
    internal_battery,
    wall_sensor,
    vdd_sensor,
    Sensor
)
from .trial import (
    TrialDescriptor,
    add_operator,
    trial
)
from .processor import (
    Button,
    Led,
    button_get,
    led_get,
    led_set,
    processor_check_errors,
    processor_get_errors,
    ConnectionPolicy,
    processor_status
)

__version__ = xipppy_str

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Helper types
class SegmentDataPacket:
    """
    Data type to mirror classic "Segments" for spike data
    """

    def __init__(self, spk=None):
        if spk is None:
            self.timestamp = 0
            self.class_id = 0
            self.wf = array.array('h', itertools.repeat(0, 52))
        else:
            self.timestamp = spk.timeDooDas
            self.class_id = spk.class_id
            wf = _c.I16Array.frompointer(spk.i16)
            self.wf = array.array('h', [wf[i] for i in range(52)])


class SegmentEventPacket:
    """
    Data type to mirror classic "Segments" for digital data
    """

    def __init__(self, event=None):
        if event is None:
            self.timestamp = 0
            self.reason = 0
            self.parallel = 0
            self.sma1 = 0
            self.sma2 = 0
            self.sma3 = 0
            self.sma4 = 0
        else:
            self.timestamp = event.timeDooDas
            self.reason = event.reason
            self.parallel = event.parallel
            self.sma1 = event.sma1
            self.sma2 = event.sma2
            self.sma3 = event.sma3
            self.sma4 = event.sma4


#
# open / close
#

def _open(use_tcp=False):
    """
    The xipppy_open context manager should be used whenever possible to open
    a connection to xipppy.

    See help(xipppy.xipppy_open) for an example.

    Multiple calls to _open will have no effect. Multiple _open calls do not
    require multiple matching _close calls.
    """

    xipppy_open._user_count += 1
    if xipppy_open._user_count == 1:
        logger.debug('Opening xipppy')
        open_fn = _c.xl_open_udp if not use_tcp else _c.xl_open_tcp
        if open_fn() != 0:
            xipppy_open._user_count = 0
            raise exception.XippPyException(
                "Library already open or failed to initialize")
    else:
        return 0


def _close():
    """
    Immediately close any open connections to the NIP. _close should not be
    called from within a xipppy_open context.
    """
    logger.debug('_close called, setting user count to 0')
    xipppy_open._user_count = 0
    return _c.xl_close()


class xipppy_open:
    """
    This is a context manager for xipppy. This is the prefered way to manage
    connections to an NIP.

    For example, to simply test the connection to the NIP:
    >>> with xipppy_open():
    ...     pass

    This context is reentrant so the following is valid (exactly one call to
    open and close is made)
    >>> def print_nip_time():
    ...     with xipppy_open():
    ...         print(time())
    >>> with xipppy_open():
    ...     print_nip_time()

    The reentrant property of this context is useful if you are building
    complex libraries on top of xipppy. You can safely wrap function calls
    that make xipppy calls in this context without
    having to detect if xipppy is already open.
    """
    _user_count = 0

    def __init__(self, use_tcp=False):
        self.use_tcp = use_tcp

    def __enter__(self):
        # Note that _open actually increments _user_count
        _open(self.use_tcp)

    def __exit__(self, type, value, traceback):
        # The following logic may seem odd, like this counter will never reach
        # zero ... but _close always sets _user_count to 0 because a closed
        # resource can't have any users.
        if xipppy_open._user_count == 0:
            logger.warning(
                'Detected a call to _close within a xipppy context. Avoid'
                'this, it can crash your program.')
        elif xipppy_open._user_count == 1:
            _close()
        elif xipppy_open._user_count > 0:
            xipppy_open._user_count -= 1

        if type:
            if isinstance(type(), exception.XippPyDisconnect):
                logger.warning('Detected disconnect from processor')
                xipppy_open._user_count = 0
                return True

            logger.exception('Exception occured in xipppy context',
                             exc_info=(type, value, traceback))


#
# data functions
#

def _cont_base(cfn, npoints, elecs, start_timestamp):
    # Build C arrays to store output and the input electrode array
    data_out = array.array('f', itertools.repeat(0, npoints * len(elecs)))
    (data_ptr, _) = data_out.buffer_info()

    elecs_in = array.array('I', elecs)
    (el_ptr, el_len) = elecs_in.buffer_info()

    ts_out = array.array('I', [1])
    (ts_ptr, _) = ts_out.buffer_info()

    # Call C
    npoints = cfn(ts_ptr, data_ptr, npoints, el_ptr, el_len, start_timestamp)

    # If data came back, trim to actual length gotten and return. Otherwise
    # nothing.
    del data_out[npoints * len(elecs):]
    return data_out, ts_out[0] if start_timestamp != 0 else 0


def cont_raw(npoints, elecs, start_timestamp=0):
    """
    Retrieve raw data (sampled at 30 kHz).

    Returns a tuple of (timestamp, data) where the timestamp is that of the
    first data, and data is a list of data points. If start_timestamp is not
    specified, the output timestamp is always 0.
    Args:
        npoints: number of datapoints to retrieve
        elecs:  list of electrodes to sample
        start_timestamp: NIP timestamp to start data at, or most recent if 0

    Returns:
    """
    return _cont_base(_c.xl_cont_raw, npoints, elecs, start_timestamp)


def cont_hires(npoints, elecs, start_timestamp=0):
    """
    Retrieve hires data (sampled at 2 kHz).

    Parameters and outputs are the same as the `cont_raw` function.
    Args:
        npoints: number of datapoints to retrieve
        elecs:  list of electrodes to sample
        start_timestamp: NIP timestamp to start data at, or most recent if 0

    Returns:
    """
    return _cont_base(_c.xl_cont_hires, npoints, elecs, start_timestamp)


def cont_hifreq(npoints, elecs, start_timestamp=0):
    """
    Retrieve hires data (sampled at 7.5 kHz).

    Parameters and outputs are the same as the `cont_raw` function.
    Args:
        npoints: number of datapoints to retrieve
        elecs:  list of electrodes to sample
        start_timestamp: NIP timestamp to start data at, or most recent if 0

    Returns:
    """
    return _cont_base(_c.xl_cont_hifreq, npoints, elecs, start_timestamp)


def cont_lfp(npoints, elecs, start_timestamp=0):
    """
    Retrieve lfp data (sampled at 1 kHz).

    Parameters and outputs are the same as the `cont_raw` function.

    If analog I/O is requested, the unfiltered analog data is retrieved, not
    filtered LFP data.
    Args:
        npoints: number of datapoints to retrieve
        elecs:  list of electrodes to sample
        start_timestamp: NIP timestamp to start data at, or most recent if 0

    Returns:
    """
    return _cont_base(_c.xl_cont_lfp, npoints, elecs, start_timestamp)


def cont_emg(npoints, elecs, start_timestamp=0):
    """
    Retrieve emg data

    Parameters and outputs are the same as the `cont_raw` function.

    If analog I/O is requested, the unfiltered analog data is retrieved, not
    filtered LFP data.
    Args:
        npoints: number of datapoints to retrieve
        elecs:  list of electrodes to sample
        start_timestamp: NIP timestamp to start data at, or most recent if 0

    Returns:
    """
    return _cont_base(_c.xl_cont_emg, npoints, elecs, start_timestamp)


def cont_status(npoints, elecs, start_timestamp=0):
    """
    Retrieve Mira status data (2 kHz)

    Every clock-cycle the Mira front end publishes status information concerning
    the implant connectivity and sensor information.

    | channel | name               | units | description
    | ------- | ------------------ | ----- | --------------------------------------
    | 0       | counter            |       | 8-bit value that increments with each
    |         |                    |       |   new implant packet [0-255]
    | 1       | xcvr_coil_v        |   V   | Transceiver coil voltage. Indicates
    |         |                    |       |   the level of driven RF wireless
    |         |                    |       |   power field. [~1.8-3.3]
    | 2       | xcvr_coil_a        |   A   | Transceiver coil current. Indicates
    |         |                    |       |   the power consumed by the trans-
    |         |                    |       |   ceiver used to power the implant.
    | 3       | xcvr_input_v       |   V   | Transceiver input voltage. Indicates
    |         |                    |       |   the voltage supplied to the trans-
    |         |                    |       |   ceiver.
    | 4       | xcvr_input_a       |   A   | Transceiver input current. Indicates
    |         |                    |       |   the total power consumed by the
    |         |                    |       |   transceiver.
    | 5       | xcvr_temp          | deg C | Transeiver internal temperature. Meant
    |         |                    |       |   to approximate the transciever's
    |         |                    |       |   patient-facing surface temperature.
    | 6       | xcvr_temp_offboard |       | (deprecated)
    | 7       | servo_state        |       | 0 = idle - coil off, waiting for user
    |         |                    |       |     command or button press.
    |         |                    |       | 1 = Comm init - enable commmunication
    |         |                    |       |     power supplies and amplifiers.
    |         |                    |       | 2 = Coil init - enable coil voltage
    |         |                    |       |     supply and individual coil drive
    |         |                    |       |     signals.
    |         |                    |       | 3 = Servoing - standard link state
    |         |                    |       |     where transceiver is modulating
    |         |                    |       |     coil power output based on implant
    |         |                    |       |     voltage level.
    |         |                    |       | 4 = Searching off - coil off.
    |         |                    |       | 5 = Searching on - coil on mat max drive
    | 8       | impl_serial        |       | Implant serial number
    | 9       | impl_deviceid      |       | Implant model number
    | 10      | impl_temp          | deg C | Implant temperature
    | 11      | impl_humidity      |       | (deprecated)
    | 12      | impl_v             |   V   | Rectified implant voltage. Indicates
    |         |                    |       |   health of received wireless power.
    | 13      | impl_ver_hw        |       | Implant hardware version
    | 14      | impl_ver_fw        |       | Implant firmware version

    Args:
        npoints: number of datapoints to retrieve
        channel:  A list of channels to retrieve. See the table above. All
        channels are returned as float arrays even if they are fundamentally
        integer quantities.
        start_timestamp: NIP timestamp to start data at, or most recent if 0

    Returns:
    """
    return _cont_base(_c.xl_cont_status, npoints, elecs, start_timestamp)


# TODO: This probably doesn't work SpikeDataBuffer::GetEventPackets() might
#      be broken (xippmex uses another function)
def spk_data(elec, max_spk=1024):
    """

    Return spike data
    Args:
        elec: desired electrode, zero indexed
        max_spk: max spikes, default, 1024

    Returns:
        tuple counts, spks - count, the number of spikes
        spks - list of SegmentDataPacket classes
    """
    c_spikes = _c.SegmentDataArray(max_spk)

    event_ids = array.array('i', itertools.repeat(0, max_spk))
    (event_ptr, _) = event_ids.buffer_info()

    n = exception.check(_c.xl_spk_data(c_spikes, event_ptr, max_spk, elec))
    spikes = [SegmentDataPacket(c_spikes[i]) for i in range(min(n, max_spk))]

    # TODO: no reason to include the count (n) here.
    return n, spikes


def spk_thresh_set(elecs, lower, upper):
    """
        Set lower and upper spike threshold.
        Args:
            elecs: list of desired electrode, zero-indexed
            lower: 'low’ spike thresholds for elecs.
            upper: 'high’ spike thresholds for elecs.
        """
    for elec in elecs:
        exception.check(_c.xl_spk_thresh_set(elec, lower, upper),
                        "Failed to set spike threshold for elec {}".format(elec))


def spk_thresh_set_lower(elecs, lower):
    """
    Set lower spike threshold.
    Args:
        elecs: list of desired electrode, zero-indexed
        lower: 'low’ spike thresholds for elecs.
    """
    for elec in elecs:
        lower_out = array.array('f', itertools.repeat(0, 1))
        (lower_ptr, _) = lower_out.buffer_info()
        upper_out = array.array('f', itertools.repeat(0, 1))
        (upper_ptr, _) = upper_out.buffer_info()
        exception.check((_c.xl_spk_thresh(lower_ptr, upper_ptr, elec)))
        rcv_upper = upper_out[0]
        exception.check(_c.xl_spk_thresh_set(elec, lower, rcv_upper),
                        "Failed to set spike threshold for elec {}".format(elec))


def spk_thresh_set_upper(elecs, upper):
    """
    Set higher spike threshold.
    Args:
        elecs: list of desired electrodes, zero-indexed
        upper: 'high’ spike thresholds for elecs.
    """
    for elec in elecs:
        lower_out = array.array('f', itertools.repeat(0, 1))
        (lower_ptr, _) = lower_out.buffer_info()
        upper_out = array.array('f', itertools.repeat(0, 1))
        (upper_ptr, _) = upper_out.buffer_info()
        exception.check((_c.xl_spk_thresh(lower_ptr, upper_ptr, elec)))
        rcv_lower = lower_out[0]
        exception.check(_c.xl_spk_thresh_set(elec, rcv_lower, upper),
                        "Failed to set spike threshold for elec {}".format(elec))


def spk_thresh(elec):
    """
    retrieve the current spike thresholds of the electrode.
    Args:
        elec: desired electrode, zero indexed
    Returns:
        tuple: holding current lower and upper spike threshold.
    """
    lower_out = array.array('f', itertools.repeat(0, 1))
    (lower_ptr, _) = lower_out.buffer_info()
    upper_out = array.array('f', itertools.repeat(0, 1))
    (upper_ptr, _) = upper_out.buffer_info()
    exception.check(_c.xl_spk_thresh(lower_ptr, upper_ptr, elec),
                    "Failed to retrieve spike threshold for elec {}".format(elec))
    return lower_out[0], upper_out[0]


def stim_data(elec, max_spk=1024):
    """
    retrieve segment data containing stim waveforms
    Args:
        elec:
        max_spk:

    Returns:
        tuple counts, events - count, the number of spikes
        events - list of SegmentDataPacket classes
    """
    c_spikes = _c.SegmentDataArray(max_spk)

    event_ids = array.array('i', itertools.repeat(0, max_spk))
    (event_ptr, _) = event_ids.buffer_info()

    n = exception.check(_c.xl_stim_data(c_spikes, event_ptr, max_spk, elec))
    spikes = [SegmentDataPacket(c_spikes[i]) for i in range(min(n, max_spk))]

    # TODO: no reason to include the count (n) here.
    return n, spikes


def digin(max_events=1024):
    """
    Retrieve digital inputs
    Args:
        max_events:

    Returns:
        tuple counts, events - count, the number of spikes
        events - list of SegmentEventPacket classes
    """
    c_events = _c.DigitalEventArray(max_events)

    event_ids = array.array('i', itertools.repeat(0, max_events))
    (event_ptr, _) = event_ids.buffer_info()

    # TODO: no check() here because the API is broken
    n = _c.xl_digin(c_events, event_ptr, max_events)
    events = [SegmentEventPacket(c_events[i]) for i in
              range(min(n, max_events))]

    # TODO: no reason to include the count (n) here.
    return n, events


def digout(outputs, values):
    """
    Produce digital outputs
    Args:
        outputs: list of integers designating desired output channels
        values: list of values, all are 0, 1 except the parallel port
            which is a 16-bit integer.

    Returns:
        None
    """
    if len(outputs) != len(values):
        raise ValueError("length of outputs and inputs must match")

    c_outputs = array.array('I', outputs)
    (outputs_ptr, _) = c_outputs.buffer_info()

    c_values = array.array('I', values)
    (values_ptr, _) = c_values.buffer_info()

    exception.check(_c.xl_digout(outputs_ptr, values_ptr, len(values)))



#
#  informational functions
#

def time():
    """Return the most recent NIP time."""
    return exception.check(_c.xl_time(), "Unable to get NIP time")


def list_elec(fe_type="", max_elecs=256):
    """
    List electrodes on a specified frontend type, returning a sequence.

    Arguments:
        fe_type: type of frontend
        max_elecs: maximum number of electrodes to return. If there are more
                   than this many, the extras will be omitted.
    """
    data_out = array.array('I', itertools.repeat(0, max_elecs))
    (data_ptr, _) = data_out.buffer_info()

    n = exception.check(_c.xl_list_elec(data_ptr, max_elecs, fe_type),
                        "unable to list electrodes")

    # Truncate array to actual size of data
    del data_out[n:]
    return data_out


def get_fe(elec):
    """Return the frontend index of the requested electrode."""
    return exception.check(_c.xl_get_fe(elec),
                           "no front end found for electrode {}".format(elec))


def get_fe_streams(elec, max_streams=32):
    """
    Return a list of stream types supported by the given electrode.
    Args:
        elec: zero indexed electrode
        max_streams: max strings to return
    """
    data = array.array('b', itertools.repeat(0, max_streams * _c.STRLEN_LABEL))
    (ptr , _) = data.buffer_info()

    n = exception.check(_c.xl_get_fe_streams(ptr, max_streams, elec),
                        "Error getting streams for fe {}".format(elec))

    ret = []
    for i in range(n):
        addr = ptr + i * _c.STRLEN_LABEL
        s = ctypes.string_at(addr)
        ret.append(s.decode('utf-8'))

    return ret


def get_nip_serial(max_size=1024):
    """
    Return string of nip serial number, eg 'R00244-0006'
    Args:
        max_size: maximum size of string
    """
    data = array.array('b', itertools.repeat(0, max_size))
    (ptr, _) = data.buffer_info()

    n = exception.check(
        _c.xl_nip_serial(ptr, max_size), "unable to get serial number")
    s = ctypes.string_at(ptr)
    return s.decode('utf-8')

def get_version():
    """
    Return dictionary of software and protocol versions.  Keys are:
    'xipp' - XIPP protocol version
    'xipplib' - underlying C library version
    'xipppy' - xipppy Python module version
    """
    versions = {'xipppy': __version__}

    max_size = 32
    data = array.array('b', itertools.repeat(0, max_size))
    (ptr, _) = data.buffer_info()

    exception.check(
        _c.xl_lib_version(ptr, max_size),
        "unable to get library version information"
        )
    versions['xipplib'] = ctypes.string_at(ptr).decode('utf-8')

    exception.check(
        _c.xl_xipp_version(ptr, max_size),
        "unable to get XIPP protcol version information"
        )
    versions['xipp'] = ctypes.string_at(ptr).decode('utf-8')

    return versions

def get_nipexec_version(max_size=1024):
    """
    Return string of nipexec version, eg '1.6.1.23'
    Args:
        max_size: maximum size of string
    """
    data = array.array('b', itertools.repeat(0, max_size))
    (ptr, _) = data.buffer_info()

    exception.check(
        _c.xl_nipexec_version(ptr, max_size),
        "unable to get nipexec version information"
    )
    s = ctypes.string_at(ptr)
    return s.decode('utf-8')


def get_fe_version(elec, max_size=1024):
    """
    Return R number for fe for given electrode
    Args:
        elec: zero indexed electrode
        max_size: maximum size of string
    """
    data = array.array('b', itertools.repeat(0, max_size))
    (ptr, _) = data.buffer_info()

    exception.check(_c.xl_fe_version(ptr, max_size, elec),
                    "unable to get front end version information for {}".format(
                        elec))
    s = ctypes.string_at(ptr)
    return s.decode('utf-8')


#
#  Signal functions
#

def signal(elec, stream_ty):
    """
    Return a bool indicating whether the stream of the given type on the given
    electrode is selected.
    Args:
        elec:
        stream_ty:
    """
    return bool(exception.check(_c.xl_signal(elec, stream_ty)))


def signal_raw(elec):
    """
    Return the selection status of a raw stream (like signal()).
    Args:
        elec:
    """
    return bool(exception.check(_c.xl_signal_raw(elec)))


def signal_lfp(elec):
    """
    Return the selection status of a LFP stream (like signal()).
    Args:
        elec:
    """
    return bool(exception.check(_c.xl_signal_lfp(elec)))


def signal_spk(elec):
    """
    Return the selection status of a spike stream (like signal()).
    Args:
        elec:
    """
    return bool(exception.check(_c.xl_signal_spk(elec)))


def signal_stim(elec):
    """
    Return the selection status of a stim stream (like signal()).
    Args:
        elec:
    """
    return bool(exception.check(_c.xl_signal_stim(elec)))


def signal_set(elec, stream_ty, val):
    """
    Select or deselect a signal type on a single electrode.

    Arguments:
        elec: electrode ID to operate on
        stream_ty: type of stream to set selection for (as from get_fe_streams())
        val: True to select, or False to deselect
    """
    return exception.check(_c.xl_signal_set(elec, stream_ty, int(val)))


def signal_set_raw(elec, val):
    """
    Set selection for a raw signal (like signal_set()).
    Args:
        elec:
        val:
    """
    return exception.check(_c.xl_signal_set_raw(elec, int(val)))


def signal_set_lfp(elec, val):
    """
    Set selection for a LFP signal (like signal_set()).
    Args:
        elec:
        val:
    """
    return exception.check(_c.xl_signal_set_lfp(elec, int(val)))


def signal_set_spk(elec, val):
    """
    Set selection for a spike signal (like signal_set()).
    Args:
        elec:
        val:
    """
    return exception.check(_c.xl_signal_set_spk(elec, int(val)))


def signal_set_stim(elec, val):
    """
    Set selection for a stim signal (like signal_set()).
    Args:
        elec:
        val:
    """
    return exception.check(_c.xl_signal_set_stim(elec, int(val)))

#
# file save
#
def signal_save(elec, stream_ty):
    """
    Return a bool indicating whether the given signal and stream will be saved
    on the processor.
    Args:
        elec:
        stream_ty:
    """
    return exception.check(_c.xl_signal_save(elec, stream_ty))

def signal_save_set(elec, stream_ty, val):
    """
    Set the file save selection on the processor for the electrode and stream.
    Args:
        elec:
        stream_ty:
        val:
    """
    return exception.check(_c.xl_signal_save_set(elec, stream_ty, val))


#
# impedance
#
def impedance(channels):
    """
    Take a list of channels and return measured impedances on those channels.
    """
    size = len(channels)
    chan = array.array('I', channels)
    result = array.array('f', size * [0])

    exception.check(
        _c.xl_imp(result.buffer_info()[0], chan.buffer_info()[0], size),
        'Impedance call failed.'
    )
    return result
