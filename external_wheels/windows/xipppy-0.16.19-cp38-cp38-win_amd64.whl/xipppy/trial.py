"""

XIPP file save API

"""
import array
import ctypes

import xipppy_capi as _c

from .processor import ConnectionPolicy
from .exception import XippPyException, error_string

class TrialDescriptor:
    """
    Data type to mirror XippTrialDesc_t for ease of use
    """

    def __init__(self, val=None):
        self._status = None
        self._file_name_base = None
        self._error_msg = None
        self._auto_stop_time = None
        self._auto_incr = None
        self._incr_num = None

        # here's where we'll keep the actual trial descriptor
        self._desc = _c.XippTrialDescriptor_t()
        self._desc.status_size = int(0)
        self._desc.file_name_size = int(0)
        self._desc.error_nsg_size = int(0)

        if val is not None:
            if val.status is not None:
                self.status = str(val.status)

            if val.file_name_base is not None:
                self.file_name_base = str(val.file_name_base)

            if val.error_msg is not None:
                self.error_msg = str(val.error_msg)

            if val.auto_stop_time is not None:
                self.auto_stop_time = int(val.auto_stop_time)

            if val.auto_incr is not None:
                self.auto_incr = int(val.auto_incr)

            if val.incr_num is not None:
                self.incr_num = int(val.incr_num)

    @property
    def status(self):
        if self._status is None:
            return None

        s = ctypes.string_at(self._status.buffer_info()[0])
        return s.decode('utf-8')

    @status.setter
    def status(self, value):
        self._status = array.array('b', bytearray(value + '\0', 'utf-8'))

        self._desc.status = self._status.buffer_info()[0]
        self._desc.status_size = len(self._status)

    @property
    def file_name_base(self):
        if self._file_name_base is None:
            return None

        s = ctypes.string_at(self._file_name_base.buffer_info()[0])
        return s.decode('utf-8')

    @file_name_base.setter
    def file_name_base(self, value):
        self._file_name_base = array.array('b', bytearray(value + '\0', 'utf-8'))
        self._desc.file_name_base = self._file_name_base.buffer_info()[0]
        self._desc.file_name_base_size = len(self._file_name_base)

    @property
    def error_msg(self):
        if self._error_msg is None:
            return None

        s = ctypes.string_at(self._error_msg.buffer_info()[0])
        return s.decode('utf-8')

    @error_msg.setter
    def error_msg(self, value):
        self._error_msg = array.array('b', bytearray(value + '\0', 'utf-8'))
        self._desc.error_msg = self._error_msg.buffer_info()[0]
        self._desc.error_msg_size = len(self._error_msg)

    @property
    def auto_stop_time(self):
        if self._auto_stop_time is not None:
            return self._auto_stop_time.value
        else:
            return None

    @auto_stop_time.setter
    def auto_stop_time(self, value):
        self._auto_stop_time = ctypes.c_uint(value)
        self._desc.auto_stop_time = ctypes.addressof(self._auto_stop_time)

    @property
    def auto_incr(self):
        if self._auto_incr is not None:
            return self._auto_incr.value
        else:
            return None

    @auto_incr.setter
    def auto_incr(self, value):
        self._auto_incr = ctypes.c_uint(value)
        self._desc.auto_incr = ctypes.addressof(self._auto_incr)

    @property
    def incr_num(self):
        if self._incr_num is not None:
            return self._incr_num.value
        else:
            return None

    @incr_num.setter
    def incr_num(self, value):
        self._incr_num = ctypes.c_uint(value)
        self._desc.incr_num = ctypes.addressof(self._incr_num)

    def cast(self):
        return self._desc


#
# trial
#

def add_operator(oper_addr, *, connection_policy=None, timeout=None):
    """ Add connection to xipp operator.

        Args:
            oper_addr: ip address of operator or short-hand
            connection_policy:  use the enum ConnectionPolicy or set to
                None to use the default.
                    ConnectionPolicy.DEFAULT
                    ConnectionPolicy.PREFER_WIRED
                    ConnectionPolicy.PREFER_WIRELESS
                    ConnectionPolicy.WIRED_ONLY
                    ConnectionPolicy.WIRELESS_ONLY
            timeout:  TCP connection timeout in milliseconds

    """
    _default = _c.XL_DEFAULT_STATUS_CONNECTION_OPTIONS
    _connection_policy = ctypes.c_int(_default.policy)
    _timeout = ctypes.c_int(_default.timeout)

    if connection_policy is not None:
        _connection_policy.value = int(connection_policy)
    if timeout is not None:
        _timeout.value = int(timeout)

    code  = ctypes.c_uint32()
    r = _c.xl_operator_add(ctypes.addressof(code),
                           str(oper_addr),
                           ctypes.addressof(_connection_policy),
                           ctypes.addressof(_timeout))
    if r < 0:
        raise XippPyException(error_string(r))

    return code.value


def lookup_operator(oper_addr):
    """ Check if a Xipp operator is already connected.

        Args:
            oper_addr: ip address of operator or short-hand
    """
    code  = ctypes.c_uint32()
    r = _c.xl_operator_lookup(ctypes.addressof(code), str(oper_addr))
    if  r < 0:
        raise XippPyException(error_string(r))

    return code.value


def trial(oper=None, status=None, file_name_base=None, auto_stop_time=None,
          auto_incr=None, incr_num=None):

    """
    Create a trial packet addressed to the operator or processor with id
    `oper`. All other arguments but oper are optional, if they aren't specified
    they will remain unchanged for the operator. 'Enable remote control' must be
    enabled for input parameters to have an effect. The resulting or current
    state corresponding to each input parameter is returned for each call. To
    query parameters only, just call with no arguments.

    Args:
        oper: operator id (>=128) or processor id (<128)
        status: a string which can be: recording, stopped, paused
        file_name_base: the base filename that the trial will record to
        auto_stop_time: the time in seconds after which recording will stop
        auto_incr: a boolean that indicates whether auto_increment is enabled
        incr_num: the value to set the current file increment counter to

    Returns: the resulting state of: status, file_name_base, auto_stop_time,
      auto_incr, incr_num

    """
    desc_in = TrialDescriptor()

    if status is not None:
        desc_in.status = str(status)

    if file_name_base is not None:
        desc_in.file_name_base = str(file_name_base)

    if auto_stop_time is not None:
        desc_in.auto_stop_time = int(auto_stop_time)

    if auto_incr is not None:
        desc_in.auto_incr = int(auto_incr)

    if incr_num is not None:
        desc_in.incr_num = int(incr_num)

    desc_out = TrialDescriptor()
    desc_out.status = str(255 * "\0")
    desc_out.file_name_base = str(4096 * "\0")
    desc_out.error_msg = str(255 * "\0")
    desc_out.auto_stop_time = int(0)
    desc_out.auto_incr = int(0)
    desc_out.incr_num = int(0)

    operator_id = ctypes.c_uint32(0)
    if oper is not None:
        operator_id.value = lookup_operator(oper)

    err_code = _c.xl_trial2(operator_id.value, desc_out.cast(), desc_in.cast())
    if (err_code < 0):
        raise RuntimeError(error_string(err_code))
    if err_code == 1:
        raise RuntimeError('No operator found')
    elif err_code == 2:
        raise RuntimeError('No response from operator')
    elif err_code == 3:
        raise RuntimeError('`status` must be: recording, stopped or paused')
    elif err_code == 4:
        raise RuntimeError('Unknown receiver code found in trial descriptor')
    elif err_code == 5 and desc_out.error_msg is not None:
        raise RuntimeError(desc_out.error_msg)
    elif err_code > 4:
        raise RuntimeError('xipplib returned an unknown error code')

    return (
        desc_out.status,
        desc_out.file_name_base,
        desc_out.auto_stop_time,
        bool(desc_out.auto_incr),
        desc_out.incr_num
    )

